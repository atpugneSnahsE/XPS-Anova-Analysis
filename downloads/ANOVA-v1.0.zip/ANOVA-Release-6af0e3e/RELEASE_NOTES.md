# ANOVA Release Notes

## Version Information
- Release Date: $(date)
- Version: See filename for version

## What's Inside

This package contains the complete ANOVA analysis system with:
- XPS spectral analysis pipeline
- Two-way ANOVA statistical analysis
- Modern web interface for non-technical users
- Command-line interface for advanced users
- Complete documentation

## Quick Start

### For Web Interface (Recommended)

**Windows:**
1. Extract the ZIP file
2. Double-click `start_web.bat`
3. Your browser will open automatically
4. Upload your Excel file and click "Analyze"

**Mac/Linux:**
1. Extract the ZIP file
2. Open Terminal
3. Navigate to the folder
4. Run: `bash start_web.sh`
5. Your browser will open automatically
6. Upload your Excel file and click "Analyze"

### For Command Line

```bash
# XPS analysis only
python main.py

# Full ANOVA pipeline
bash start.sh anova
```

## Documentation

- **START_HERE.md** - Main entry point (read this first!)
- **WEB_SETUP_GUIDE.md** - Complete web interface guide
- **README.md** - Original documentation
- **WEB_BUILD_SUMMARY.md** - Technical details

## System Requirements

- Python 3.11 or later (automatically checked)
- 4 GB RAM minimum
- 1 GB free disk space
- Windows 7+, macOS 10.13+, or modern Linux

## Support

If you encounter any issues:
1. Check the troubleshooting section in WEB_SETUP_GUIDE.md
2. Ensure you have Python 3.11+ installed
3. Check error messages in the command window

## License

Same as original ANOVA project.
